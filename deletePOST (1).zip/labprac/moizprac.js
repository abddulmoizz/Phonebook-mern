let express = require('express');
let fs= require('fs');
let bp= require('body-parser');
let app= express();
let port= 3001;
let users=JSON.parse(fs.readFileSync('users.json'));
app.use(bp.urlencoded({extended: true}));
app.set('view engine', 'ejs');

app.get('/',(req,res)=>{
    res.redirect('home');
});

app.get('/home',(req,res)=>{    
    res.render('home',{users});
});

app.get('/add',(req,res)=>{
res.render('add');
});

app.post('/add',(req,res)=>{
    let user=req.body;
    users.push(user);
    fs.writeFileSync('users.json',JSON.stringify(users));
    res.redirect('/home');
});

app.get('/show',(res,req)=>{
    let id=parseInt(req.query.id);
    let user=users[id-1];
    res.render('show',{user});    
});



app.listen(port,()=>{
    console.log(`Server is running on port http://localhost:${port}`);
});