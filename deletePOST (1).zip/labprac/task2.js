let express = require('express');
let fs = require('fs');
let bp = require('body-parser');
let session = require('express-session');
let cookie = require('cookie-parser');
let flash = require('connect-flash');
let port = 3000;
let app = express();
app.use(session({
    secret: 'secret',
    resave: true,
    cookie: { maxAge: 600000 },
    saveUninitialized: true
}));
app.set('view engine', 'ejs');
app.use(bp.urlencoded({ extended: true }));
app.use(cookie());
app.use(flash());


let users = JSON.parse(fs.readFileSync('users.json'));
let logincred = JSON.parse(fs.readFileSync('logincred.json'));


app.get('/', (req, res) => {
    res.redirect('login');
});
const isAuthenticated = (req, res, next) => {
    if (req.session.userLoggedIn) {
        next();
    }
    else {
        req.flash("error2", "Please Login to proceed");
        res.redirect('/login');
    };
};

app.get('/signup', (req, res) => {
    res.render('signup');
});

app.post('/signup', (req, res) => {
    let user = req.body;
    logincred.push(user);
    fs.writeFileSync('logincred.json', JSON.stringify(logincred));
    res.redirect('/login');
});


app.get('/guestview', (req, res) => {
    res.render('guestview', { users });
});

app.get('/login', (req, res) => {
    let username = req.cookies.username;
    res.render('login', { username, message: req.flash('error'), message2: req.flash('error2')});
});

app.post('/login', (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    let user = logincred.find(user => user.username === username && user.password === password);
    if (user) {
        req.session.userLoggedIn = true;
        res.cookie('username', username, { maxAge: 600000 });
        res.redirect('/home');
    } else {
        req.flash("error", "Invalid username or password");
        res.redirect('/login');
    }
});


app.get('/home', isAuthenticated,(req, res) => {
    let username = req.cookies.username;
    res.render('home', { users, username });
});

app.get('/add', isAuthenticated, (req, res) => {
    res.render('add');
});



app.post('/add', isAuthenticated, (req, res) => {
    let newuser = { id: users.length + 1, name: req.body.name, gender: req.body.gender, city: req.body.city, phone: req.body.phone };
    users.push(newuser);
    fs.writeFileSync('users.json', JSON.stringify(users));
    res.redirect('/home');


});

app.get('/show', isAuthenticated, (req, res) => {
    let userID = parseInt(req.query.id);
    let user = users.find(u => parseInt(u.id) === userID);
    if (user) {
        res.render('show', { user });
    }
    else {
        res.send('User not found');
    }

});

app.get('/edit', isAuthenticated, (req, res) => {
    let userID = parseInt(req.query.id);
    let user = users.find(u => parseInt(u.id) === userID);
    if (user) {
        res.render('edit', { user });
    }
    else {
        res.send('User not found');
    }
});

app.post('/edit', isAuthenticated, (req, res) => {
    let userid = parseInt(req.body.id);
    let userindex = users.findIndex(u => parseInt(u.id) === userid);
    if (userindex !== -1) {
        users[userindex] = { id: userid, name: req.body.name, gender: req.body.gender, city: req.body.city, phone: req.body.phone };
        fs.writeFileSync('users.json', JSON.stringify(users));
        res.redirect('/home');

    }
    else {
        res.send('User not found');
    }

});

app.post('/delete', isAuthenticated, (req, res) => {
    let id = parseInt(req.body.id);
    users = users.filter(user => parseInt(user.id) !== parseInt(id));
    fs.writeFileSync('users.json', JSON.stringify(users));

    res.redirect('/home');

});

app.post('/logout', isAuthenticated,(req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

app.listen(port, () => {
    console.log(`Server is running on port http://localhost:${port}`);
});